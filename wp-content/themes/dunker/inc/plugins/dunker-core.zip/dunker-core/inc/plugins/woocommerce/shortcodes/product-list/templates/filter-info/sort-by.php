<div class="qodef-product-list-ordering">
	<a class="qodef-m-orderby-opener" href="javascript:void(0)">
		<span class="qodef-m-text"><?php esc_html_e( 'Default Sorting', 'dunker' ); ?></span>
		<span class="qodef-m-icon"></span>
	</a>
	<ul class="qodef-m-orderby-list qodef-filter-links" >
		<?php echo dunker_core_get_product_list_sorting_filter(); ?>
	</ul>
</div>
