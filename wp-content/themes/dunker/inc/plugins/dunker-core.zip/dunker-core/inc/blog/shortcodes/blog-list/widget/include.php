<?php

include_once DUNKER_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-dunkercore-blog-list-widget.php';
include_once DUNKER_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-dunkercore-simple-blog-list-widget.php';
