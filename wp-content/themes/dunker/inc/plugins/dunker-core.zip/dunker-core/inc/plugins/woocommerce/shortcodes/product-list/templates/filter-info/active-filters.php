<div class="qodef-active-filters">
	<a class="qodef--clear qodef-button qodef-layout--textual  qodef-html--link" href="#" target="_self">
		<span class="qodef-m-text"><?php echo esc_html__( 'Reset', 'dunker-core' ); ?></span>
	</a>
</div>
