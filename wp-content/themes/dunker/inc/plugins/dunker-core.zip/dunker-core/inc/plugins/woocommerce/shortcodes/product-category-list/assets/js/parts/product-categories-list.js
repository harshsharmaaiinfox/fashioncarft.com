(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.dunker_core_product_category_list                    = {};
	qodefCore.shortcodes.dunker_core_product_category_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.dunker_core_product_category_list.qodefSwiper        = qodef.qodefSwiper;

})( jQuery );
