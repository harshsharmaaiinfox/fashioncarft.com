<?php

include_once DUNKER_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-category-list/variations/simple/simple.php';
