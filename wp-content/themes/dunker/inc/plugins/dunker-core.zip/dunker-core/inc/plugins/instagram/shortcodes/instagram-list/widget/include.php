<?php

include_once DUNKER_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-dunkercore-instagram-list-widget.php';
