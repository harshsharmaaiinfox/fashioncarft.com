<?php

include_once DUNKER_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/helper.php';
include_once DUNKER_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-dunkercore-instagram-list-shortcode.php';
