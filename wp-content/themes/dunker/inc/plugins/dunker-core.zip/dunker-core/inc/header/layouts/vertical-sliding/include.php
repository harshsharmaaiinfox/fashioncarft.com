<?php

include_once DUNKER_CORE_INC_PATH . '/header/layouts/vertical-sliding/helper.php';
include_once DUNKER_CORE_INC_PATH . '/header/layouts/vertical-sliding/class-dunkercore-vertical-sliding-header.php';
include_once DUNKER_CORE_INC_PATH . '/header/layouts/vertical-sliding/dashboard/admin/vertical-sliding-header-options.php';
include_once DUNKER_CORE_INC_PATH . '/header/layouts/vertical-sliding/dashboard/meta-box/vertical-sliding-header-meta-box.php';
