(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.dunker_core_interactive_product_categories = {};

})( jQuery );
