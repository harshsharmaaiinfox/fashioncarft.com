<?php

include_once DUNKER_CORE_INC_PATH . '/fullscreen-menu/widgets/fullscreen-menu-opener/class-dunkercore-fullscreen-menu-opener-widget.php';
