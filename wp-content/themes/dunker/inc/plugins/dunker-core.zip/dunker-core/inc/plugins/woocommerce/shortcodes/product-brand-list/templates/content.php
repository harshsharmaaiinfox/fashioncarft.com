<div <?php qode_framework_class_attribute( $holder_classes ); ?>>
	<div class="qodef-grid-inner">
		<?php
		// Include items
		dunker_core_template_part( 'plugins/woocommerce/shortcodes/product-brand-list', 'templates/loop', '', $params );
		?>
	</div>
</div>
