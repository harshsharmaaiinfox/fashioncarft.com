<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

include_once DUNKER_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-wishlist-for-woocommerce/helper.php';
include_once DUNKER_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-wishlist-for-woocommerce/class-dunkercore-woocommerce-qode-wishlist-for-woocommerce.php';
