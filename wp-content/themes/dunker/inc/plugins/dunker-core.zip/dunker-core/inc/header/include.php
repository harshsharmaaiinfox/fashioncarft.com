<?php

include_once DUNKER_CORE_INC_PATH . '/header/helper.php';
include_once DUNKER_CORE_INC_PATH . '/header/class-dunkercore-header.php';
include_once DUNKER_CORE_INC_PATH . '/header/class-dunkercore-headers.php';
include_once DUNKER_CORE_INC_PATH . '/header/template-functions.php';
