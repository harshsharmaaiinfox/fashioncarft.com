<a href="#" class="qodef-filter-opener" target="_self">
	<span><?php echo esc_html__( 'Filters', 'dunker-core' ); ?></span>
	<?php dunker_core_render_svg_icon( 'filter-opener' ); ?>
</a>
