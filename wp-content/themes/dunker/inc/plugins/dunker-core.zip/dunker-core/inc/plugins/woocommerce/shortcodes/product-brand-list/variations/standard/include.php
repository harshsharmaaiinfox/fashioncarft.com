<?php

include_once DUNKER_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-brand-list/variations/standard/standard.php';
