<?php

include_once DUNKER_MEMBERSHIP_INC_PATH . '/widgets/login-opener/class-dunkermembership-login-opener-widget.php';
