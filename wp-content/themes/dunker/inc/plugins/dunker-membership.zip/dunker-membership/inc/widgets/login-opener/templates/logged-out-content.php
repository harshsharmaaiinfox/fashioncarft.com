<a href="#" class="qodef-login-opener">
	<span class="qodef-login-opener-icon"><?php echo dunker_core_get_svg_icon('member'); ?></span>
	<span class="qodef-login-opener-text screen-reader-text"><?php esc_html_e( 'Login / Register', 'dunker-membership' ); ?></span>
</a>
